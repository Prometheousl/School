/*
 * int.h
 *
 *  Created on: Sep 6, 2017
 *      Author: alexl
 */

#ifndef CONVERSIONS_H_
#define CONVERSIONS_H_

#include <stdio.h>
#include "int.h"
#include "m_string.h"

extern INTEGER *STRINGtoINTEGER(STRING *s);
extern STRING *INTEGERtoSTRING(INTEGER *i);

#endif /* INT_H_ */
